#ifndef CLOUD_LINK_H
#define CLOUD_LINK_THREAD_H

#include "wigadget.h"

void start_cloud_link(void);
void cloud_link_task(void *param);


#endif

